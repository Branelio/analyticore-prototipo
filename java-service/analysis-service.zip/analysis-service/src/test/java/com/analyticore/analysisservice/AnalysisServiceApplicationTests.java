package com.analyticore.analysisservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnalysisServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
